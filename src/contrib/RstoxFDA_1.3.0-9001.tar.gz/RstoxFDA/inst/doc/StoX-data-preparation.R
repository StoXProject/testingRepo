## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
	message = FALSE,
	warning = FALSE
)
library(RstoxFDA)

## ----docfunction, echo=TRUE---------------------------------------------------
?RstoxFDA::ConvertWeightBiotic

## ----docformat, echo=TRUE-----------------------------------------------------
?RstoxBase::StratumPolygon

## ----resourceformat, echo=TRUE------------------------------------------------
?RstoxFDA::DefineLengthConversionParameters

