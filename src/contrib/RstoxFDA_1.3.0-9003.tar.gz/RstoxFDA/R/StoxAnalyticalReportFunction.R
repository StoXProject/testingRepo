#' @noRd
ReportAnalyticalCatchAtAge <- function(){}